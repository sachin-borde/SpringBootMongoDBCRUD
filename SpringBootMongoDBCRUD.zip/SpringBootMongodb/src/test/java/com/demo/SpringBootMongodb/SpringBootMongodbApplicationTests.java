package com.demo.SpringBootMongodb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMongodbApplicationTests {

	@Test
	void contextLoads() {
	}

}
